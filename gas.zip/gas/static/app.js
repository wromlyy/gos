let map, userLat, userLon, pickedLat, pickedLon;
const statusEl = document.getElementById("status");

function setStatus(t){statusEl.textContent=t}

function initMap(lat,lon){
  document.querySelector(".hero").style.display="none";
  document.querySelector(".content").style.display="block";
  map=L.map("map").setView([lat,lon],13);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{attribution:"© OpenStreetMap"}).addTo(map);
  L.marker([lat,lon]).addTo(map).bindPopup("Вы здесь").openPopup();
  map.on("click",e=>{pickedLat=e.latlng.lat;pickedLon=e.latlng.lng;});
  loadNearby(lat,lon);
}

async function loadNearby(lat,lon){
  try{
    const r=await fetch("/api/nearby",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({lat,lon})});
    const d=await r.json();
    if(!d.ok) throw new Error();
    d.places.forEach(p=>L.marker([p.lat,p.lon]).addTo(map).bindPopup(`<b>${escapeHtml(p.name)}</b><br>${escapeHtml(p.address||"")}`));
    const own=await fetch("/api/places"); const approved=await own.json();
    approved.forEach(p=>L.marker([p.lat,p.lon]).addTo(map).bindPopup(`<b>${escapeHtml(p.name)}</b><br>${escapeHtml(p.address||"")}`));
  }catch(e){setStatus("Не удалось загрузить . Попробуйте ещё раз.");}
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}

document.getElementById("locate").onclick=()=>{
  setStatus("Запрашиваем разрешение на геолокацию…");
  if(!navigator.geolocation){setStatus("Ваш браузер не поддерживает геолокацию.");return;}
  navigator.geolocation.getCurrentPosition(async pos=>{
    userLat=pos.coords.latitude; userLon=pos.coords.longitude;
    // Explicit user action + browser permission are required before this is sent.
    await fetch("/api/location",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({lat:userLat,lon:userLon})});
    initMap(userLat,userLon);
  },err=>{
    if(err.code===1) setStatus("Геолокация отклонена. Нажмите «Включить геолокацию» и разрешите её в настройках браузера.");
    else setStatus("Не удалось получить геолокацию. Попробуйте ещё раз.");
  },{enableHighAccuracy:true,timeout:10000,maximumAge:60000});
};

document.getElementById("addBtn").onclick=()=>document.getElementById("modal").classList.remove("hidden");
function closeModal(){document.getElementById("modal").classList.add("hidden")}
document.getElementById("sendPlace").onclick=async()=>{
  if(pickedLat==null){document.getElementById("addStatus").textContent="Сначала выберите точку на карте.";return}
  const body={name:document.getElementById("pname").value,address:document.getElementById("paddr").value,fuel:document.getElementById("pfuel").value,lat:pickedLat,lon:pickedLon};
  const r=await fetch("/api/places",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  const d=await r.json(); document.getElementById("addStatus").textContent=d.message||d.error||"Готово";
};
